"""AuthKit - authentication and authorisation facilities

Copyright James Gardner 2005-2007 james at pythonweb dot org MIT Licence 
see http://www.opensource.org/licenses/mit-license.php
"""

