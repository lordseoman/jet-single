"""\
Please update your code to use authkit.authorize.wsgi_adaptors instead of this
module.
"""

from authkit.authorize.wsgi_adaptors import *
